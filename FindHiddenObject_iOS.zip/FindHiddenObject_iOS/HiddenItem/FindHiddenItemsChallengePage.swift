//
//  FindHiddenItemsChallengePage.swift
//  HiddenItem
//
//  Created by Yeon Tan on 14/01/2025.
//

import SwiftUI

struct FindHiddenItemsChallengePage: View {
    var imageInfo : TrackableImageHolder
    @State var noItemIsSelected : Bool = false
    @State var selectedItem : String = ""
    @State var challengeTitle : String = "Click the image to select the hidden item"
    @State var targetBoxCoordinate : CGPoint? = CGPoint(x:0,y:0)
    @State var correctLocatedItems : [String] = []
    @State var locatedCorrectly : Bool = false
    let alertTitle = "Congratulations !!!"
    @State var challengeCompleted : Bool = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) var modelContext
    @Environment(\.scenePhase) var scenePhase
    @State var showNoItemIsSelectedAlert : Bool = false
    @State var startTime : Date = Date.now
    //@State var endTime : Date
    @State var CompletedTimeDescription : String = ""
    
    func getHiddenItems() -> [String] {
        return imageInfo.HiddenObjectPixelLocation.keys.sorted()
    }
    
    func restartChallenge() {
        
        withAnimation{
            selectedItem = ""
            challengeCompleted = false
            locatedCorrectly = false
            challengeCompleted = false
            targetBoxCoordinate = CGPoint(x:0,y:0)
            correctLocatedItems = []
            showNoItemIsSelectedAlert = false
            startTime = Date.now
            CompletedTimeDescription = ""
            imageInfo.isChallengeCompleted = false
            
        }
        
        do {
            try modelContext.save()
            print("modelContext Challenge completed saved")
        }
        catch{
            print(error)
        }
    }
    var body: some View {
        HStack{
            Spacer()
            Button ("Restart"){
                restartChallenge()
            }
        }.padding([.trailing],10)
            .padding(.bottom,10)
        if selectedItem == "" {
            Text(challengeTitle).padding(5)
        }
        else
         {
            Text("Find the \(Text(selectedItem.capitalized).foregroundColor(.red).font(.title)) now ").padding(2) // ? Why cannot put padding inside \(Text())
        }
        
        
        
            
        
        ZStack{
            
            GeometryReader { geometry in
                
                Image(imageInfo.imageName)
                    .resizable()
                    .frame(width: 350, height: 600, alignment: .center)
                    //.containerRelativeFrame([.horizontal, .vertical])
                //.aspectRatio(contentMode: .fit)
                    //.border(.red, width: 2)
                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    .accessibilityIdentifier("FindHiddenItemsChallenge")
                    .onTapGesture { tapLocation in
                        if selectedItem == "" { // If there is no item selected in the modal, will trigger modal again
                            noItemIsSelected = true
                        }
                        else {  // If item is selected, then start looking for hidden item
                            if let guessLocationItem = imageInfo.HiddenObjectPixelLocation[selectedItem] {
                                var LocationArrayinCGPoint :[CGPoint] = []
                                guessLocationItem.forEach {
                                    location in
                                    guard let x=location["x"], let y=location["y"] else {return}
                                    print("GuessLocation X :\(x) Y : \(y)")
                                    LocationArrayinCGPoint.append(CGPoint(x: x, y: y))
                                    //                                              print(tapLocation)
                                    
                                    //475 × 540
                                    //398.0, 454.3333282470703
                                    // Beach original : 564 × 846
                                    //399.0, 598.6666564941406
                                    // Under the Sea : 564 × 694
                                    // 395.0, 484.999994913737
                                    
                                }
                                print(tapLocation)
                                targetBoxCoordinate = tapLocation
                                if isPointInPolygon(point: tapLocation, vertices: LocationArrayinCGPoint) {
                                    // If correct item is located
                                    locatedCorrectly = true
                                    correctLocatedItems.append(selectedItem)
                                    
                                    print("Guess correctly !!!")
                                    //noItemIsSelected = true
                                    
                                    //print(correctLocatedItems)
                                    //print(imageInfo.HiddenObjectPixelLocation)
                                    
                                    //                                if correctLocatedItems.count == imageInfo.HiddenObjectPixelLocation.count {
                                    //                                    challengeCompleted = true
                                    //                                    locatedCorrectly = false
                                    //                                }
                                }
                            }
                            else { // No such item in imageInfo.HiddenObjectPixelLocation
                                noItemIsSelected = true
                            }
                        }
                    }
            //.frame(width: 350, height: 600) // List Ending
        }
            if selectedItem != "" {
                TargetBoxView(targetBoxCoordinates: $targetBoxCoordinate)
            }
            if let tbc = targetBoxCoordinate  {
                TickWrapper(targetBoxCoordinate: tbc, correctLocatedItems: correctLocatedItems , locatedCorrectly : locatedCorrectly)
                    .onChange(of: correctLocatedItems) {
                        if correctLocatedItems.count == imageInfo.HiddenObjectPixelLocation.count {
                            challengeCompleted = true
                            imageInfo.isChallengeCompleted = true
                            locatedCorrectly = false
                            let endTime = Date.now
                            let completedTimeInterval = endTime.timeIntervalSince(startTime) as Double
                            print("start time is \(startTime)")
                            print("endTime is \(endTime)")
                            CompletedTimeDescription = String(format: "You completed in %.2f seconds !!!", completedTimeInterval) //"You completed in \(completedTimeInterval.rounded(2)) seconds !!!"
                            
                            do {
                                try modelContext.save()
                                print("modelContext Challenge completed saved")
                            }
                            catch{
                                print(error)
                            }
                            
                        }
                    }
            }
            
        }
        .frame(width: 350, height: 600)
        .border(.brown, width: 2)
        
        
            .onAppear{
                startTime = Date.now
            }
        // When correctly locate the hidden item, show alert to notify user
            .alert(alertTitle, isPresented: $locatedCorrectly, presenting: selectedItem) { item in
                Text("You found the \(Text(item).foregroundColor(.black).bold()) correctly !!!").font(.headline)
                Button("Ok"){
                    noItemIsSelected = true
                    selectedItem = ""
                }
            }
        // Show this alert when all items are
            .alert(CompletedTimeDescription, isPresented: $challengeCompleted) {
                
                Button("Ok"){
                    noItemIsSelected = false
                    selectedItem = ""
                    challengeTitle = "Challenge Completed !!!"
                }
                Button ("Back to Gallery"){
                    dismiss()
                }
            }
            .alert("No Item is selected !!!", isPresented: $showNoItemIsSelectedAlert){
                Button("Cancel"){
                    noItemIsSelected = false
                }
                Button("Select Again"){
                    noItemIsSelected = true
                }
            }
        
        // To show modal when no item is selected or select new item after located correctly
            .sheet(isPresented: $noItemIsSelected){
                VStack{
                    HStack {
                        Button("Cancel") {
                            noItemIsSelected = false
                            selectedItem = ""
                            challengeTitle = "Click the image to select the hidden item"
                            //dismiss()
                        }.padding(20)
                        Spacer()
                        Button("Select") {
                            // If No item is selected but tap Select button, show alert
                            if selectedItem == "" {
                                
                                showNoItemIsSelectedAlert = true
                                print("After showNoItemIsSelectedAlert")
                                
                            }
                            else {
                                
                                //challengeTitle = "Find the \(selectedItem)) now !!!"
                                noItemIsSelected = false
                                //dismiss()
                            }
                            
                        }.padding(20)
                    }
                    List {
                        VStack {
                            Menu {
                                ForEach(Array(imageInfo.HiddenObjectPixelLocation.keys), id: \.self) { item in
                                    Button(item) {
                                        selectedItem = item
                                    }.disabled( correctLocatedItems.contains(item))
                                }
                            } label : {
                                Text("Click to select the hidden item to find")
                            }
                            if selectedItem != "" {
                                Divider()
                                Text("You selected \(Text(selectedItem.capitalized).foregroundStyle(.red).font(.headline))")
                                
                            }
                        }
                        
                    }
                    
                    
                    //                        Picker("Select the hidden item to find", selection: $selectedItem){
                    //                            ForEach(Array(imageInfo.HiddenObjectPixelLocation.keys), id: \.self) { item in
                    //                                Text(item).tag(item).disabled(true)
                    //                            }
                    //                        }
                    
                }
                
            }
            .onChange(of: scenePhase) {
                print("In the scene phase onChange")
                if scenePhase == .background && selectedItem != "" {
                    //Create notification when the user leaves the app from FindHiddenItemChallengePage
                    print("Before Created notification")
                    let NotificationContent = UNMutableNotificationContent()
                    NotificationContent.title = "Hidden Item"
                    NotificationContent.subtitle = "You still haven't found the \(selectedItem)"
                    NotificationContent.sound = UNNotificationSound.default
                    
                    let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 0.2, repeats: false)
                    let request = UNNotificationRequest(identifier: "HiddenItemNotification", content: NotificationContent, trigger: notificationTrigger)
                    
                    UNUserNotificationCenter.current().add(request)
                    print("Created notification")
                }
                
            }
            
    }
        
}

//#Preview(traits: .modifier(ImageHolderForPreview())) {
//
//    FindHiddenItemsChallengePage(imageInfo: (ImageHolder.images[0]))
//
//}
