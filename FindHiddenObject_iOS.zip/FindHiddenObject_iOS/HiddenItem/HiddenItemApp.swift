//
//  HiddenItemApp.swift
//  HiddenItem
//
//  Created by Yeon Tan on 09/01/2025.
//

import SwiftUI
import SwiftData
import BackgroundTasks
import Foundation

@main
struct HiddenItemApp: App {
    @State var userAuthenticationObject = userAuthentication()
    @State var holder = if #available(iOS 15, *) {
                        ImageHolder(url: "http://localhost:6688/ios/getImages")
                    }
                    else { ImageHolder(url:  "http://localhost:6688/getImages") } // Previous URL : "http://localhost:6677/api/images"
    @Query(sort: \TrackableImageHolder.imageName) var trackableImageHolders: [TrackableImageHolder]
    @Environment(\.modelContext) var modelContext
    
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            TrackableImageHolder.self,
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()
    
    
    
    //@Environment(\.scenePhase) var scenePhase
    
    init () {
        
        // Requesting for Notification Approval
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
            if success {
                print("Notification Approved")
            }
            else if let error {
                print (error)
            }
        }
        
        // Registeration of
        
    }
    @State var isSplashScreenShown: Bool = false
    
    var body: some Scene {
        
        WindowGroup {
            ZStack {
                
                if userAuthenticationObject.isAuthenticated {
                    if isSplashScreenShown {
                        MainPage().environment(userAuthenticationObject).environment(holder)
                    }
                    else {
                        
                        SplashScreenView(isSplashScreenShown: $isSplashScreenShown)
                    }
                }
                else {
                    LoginPage().environment(userAuthenticationObject)
                }
            }
          
        }
        .modelContainer(sharedModelContainer)
        .backgroundTask(.appRefresh("CheckAndUpdateTheFreeImagesFromBackEnd")) { @MainActor in
            scheduleTaskInBackground() //Reschedule
            do{
                print("Inside appRefresh")
                let container =  try ModelContainer(for: TrackableImageHolder.self)
                let containerMainContext =  container.mainContext
                checkUpdatesFromBackEnd(trackableImageHolders: trackableImageHolders, holder: holder, modelContext: containerMainContext)
            }
            catch {
                print(error)
            }
            
            
        }
    }
}

func scheduleTaskInBackground () {
    print("Inside scheduleTaskInBackground")
    let today = Calendar.current.startOfDay(for: .now)
    let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: today)!
    let afternoonPeriod = DateComponents(hour: 15)
    let startAt3PM = Calendar.current.date(byAdding: afternoonPeriod, to: tomorrow)!
    
    let request = BGAppRefreshTaskRequest(identifier: "CheckAndUpdateTheFreeImagesFromBackEnd")
    request.earliestBeginDate = startAt3PM
    try? BGTaskScheduler.shared.submit(request)
    
}

func checkUpdatesFromBackEnd(trackableImageHolders: [TrackableImageHolder], holder: ImageHolder, modelContext: ModelContext) {
    if trackableImageHolders.isEmpty {
        print("TrackableImages is Empty, directly fetch it from Back End")
        for image in holder.images {
            let trackableImage = TrackableImageHolder(imageID: image.imageID, imageName: image.imageName, HiddenObjectPixelLocation: image.HiddenObjectPixelLocation, imageURL: image.imageURL)
            
            modelContext.insert(trackableImage)
        }
        do {
            try modelContext.save()
            print("ModelContext Saved Inside Empty ImageView Task")
        }
        catch {
            print(error)
        }
    }
    
    else {
        print("TrackableImages is not Empty, try to see if there is extra image to fetch")
        //print("Current TrackableImages is \(trackableImages)")
        for image in holder.images {
            var existed = false
            for trackableImage in trackableImageHolders {
                print("Inside comparison closure")
                //print("image is \(image.imageName), ID is \(image.imageID)")
                //print("TrackableImage is \(trackableImage.imageName), ID is \(trackableImage.imageID)")
                print(trackableImage.imageName)
                if trackableImage.imageID == image.imageID {
                    existed = true
                    print("Same Item Found")
                }
            }
            if !existed {
                print("Extra image is \(image.imageName)")
                let trackableImage = TrackableImageHolder(imageID: image.imageID, imageName: image.imageName, HiddenObjectPixelLocation: image.HiddenObjectPixelLocation, imageURL: image.imageURL)
                
                modelContext.insert(trackableImage)
            }
            
        }
        do {
            try modelContext.save()
            print("ModelContext Saved Inside NOT EMPTY ImageView Task")
        }
        catch {
            print(error)
        }
    }
}

