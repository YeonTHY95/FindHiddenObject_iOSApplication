//
//  ImageHolderForPreview.swift
//  HiddenItem
//
//  Created by Yeon Tan on 15/01/2025.
//

import Foundation
import SwiftUI

struct ImageHolderForPreview : PreviewModifier {
    
    
    static func makeSharedContext() async throws -> ImageHolder {
        let imageHolder = ImageHolder(url: "http://localhost:6677/api/images")
        return imageHolder
    }
    
    func body(content: Content, context: ImageHolder) -> some View {
        content.environment( context)
    }
        
    
}
