//
//  ImageView.swift
//  HiddenItem
//
//  Created by Yeon Tan on 13/01/2025.
//

import SwiftUI
import SwiftData

struct ImageView: View {
    //@State var holder = ImageHolder(url: "http://localhost:6677/api/images")
    @Environment(ImageHolder.self) var holder
    @State var positionIndex: String?
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \TrackableImageHolder.imageID) var trackableImages: [TrackableImageHolder]
    @Environment(\.refresh) var refresh
    
    //var imageHolder : ImageHolder? = ImageHolder(url: "http://localhost:6677/api/images")
    var body: some View {
        
        NavigationStack {
            ScrollView(.horizontal) {
                LazyHStack(spacing: 5) {
                    ForEach(trackableImages, id: \.imageID) { image in // Previous : holder.images
                        NavigationLink
                        {
                            //Image(image.imageName)
                            FindHiddenItemsChallengePage(imageInfo: image) // Previous : imageInfo: image
                        } label : {
                            
                            ZStack {
                                Image(image.imageName).resizable()//.frame(width: 300, height: 300)
                                //.aspectRatio(1/1,contentMode: .fit)
                                    .containerRelativeFrame([.horizontal,], count:1, spacing : 30)
                                if image.isChallengeCompleted {
                                Image(systemName: "checkmark.circle.fill").resizable().frame(width: 250, height: 250)
                                }
                            }
                        }.accessibilityIdentifier(image.imageName)
                    }
                }.scrollTargetLayout()
                 
            }
//            .refreshable{
//                print("Inside refreshable")
//                checkUpdatesFromBackEnd(trackableImageHolders: trackableImages, holder: holder, modelContext: modelContext)
//            }
            .border(Color.blue)
            .scrollTargetBehavior(.paging)
            .navigationTitle(Text("Image Gallery"))
            .scrollPosition(id: $positionIndex)
            
            
            IndicatorView(position : $positionIndex, imagesName : trackableImages  ) // Previous : IndicatorView(holder : $holder , position : $positionIndex)
        }
        
        .frame(width: 500, height: 500)
        
        .task {
            
            print("Inside ImageView Task")
            checkUpdatesFromBackEnd(trackableImageHolders: trackableImages, holder: holder, modelContext: modelContext)
//            if trackableImages.isEmpty {
//                print("TrackableImages is Empty, directly fetch it from Back End")
//                for image in holder.images {
//                    let trackableImage = TrackableImageHolder(imageID: image.imageID, imageName: image.imageName, HiddenObjectPixelLocation: image.HiddenObjectPixelLocation, imageURL: image.imageURL)
//                    
//                    modelContext.insert(trackableImage)
//                }
//                do {
//                    try modelContext.save()
//                    print("ModelContext Saved Inside Empty ImageView Task")
//                }
//                catch {
//                    print(error)
//                }
//            }
//            
//            else {
//                print("TrackableImages is not Empty, try to see if there is extra image to fetch")
//                //print("Current TrackableImages is \(trackableImages)")
//                for image in holder.images {
//                    var existed = false
//                    for trackableImage in trackableImages {
//                        print("Inside comparison closure")
//                        //print("image is \(image.imageName), ID is \(image.imageID)")
//                        //print("TrackableImage is \(trackableImage.imageName), ID is \(trackableImage.imageID)")
//                        print(trackableImage.imageName)
//                        if trackableImage.imageID == image.imageID {
//                            existed = true
//                            print("Same Item Found")
//                        }
//                    }
//                    if !existed {
//                        print("Extra image is \(image.imageName)")
//                        let trackableImage = TrackableImageHolder(imageID: image.imageID, imageName: image.imageName, HiddenObjectPixelLocation: image.HiddenObjectPixelLocation, imageURL: image.imageURL)
//                        
//                        modelContext.insert(trackableImage)
//                    }
//                    
//                }
//                do {
//                    try modelContext.save()
//                    print("ModelContext Saved Inside NOT EMPTY ImageView Task")
//                }
//                catch {
//                    print(error)
//                }
//            }
            
        }
        
        
    }
}

//struct IndicatorView: View {
//    //@Binding var holder : ImageHolder
//    @Binding var position : String?
//    var imagesName : [TrackableImageHolder] //{
//        //holder.images
//    //}
//    
//    var body: some View {
//        
//        return HStack {
//            ForEach(imagesName, id:\.imageID){ image in
//                Button {
//                    withAnimation{
//                        position = image.imageID
//                    }
//                } label : {
//                        Image(systemName: "circle.fill")
//                            .foregroundStyle(position == image.imageID ? Color.blue : Color.gray)
//                    }
//                    
//                    
//                }.background(RoundedRectangle(cornerRadius: 10))
//            }
//        }
//        
//    }

#Preview {
    ImageView()
}
