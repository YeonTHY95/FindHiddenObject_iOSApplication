//
//  MainPage.swift
//  HiddenItem
//
//  Created by Yeon Tan on 20/01/2025.
//

import SwiftUI

struct MainPage: View {
    let logoutURL = "http://localhost:6688/logout"
    @Environment(userAuthentication.self) var userAuthenticationObject
    @Environment(\.scenePhase) var scenePhase
    
    func logoutAction(){
        var logoutRequest = URLRequest(url: URL(string: logoutURL)!)
        logoutRequest.httpMethod = "POST"
        let task = URLSession.shared.dataTask(with: logoutRequest) { responseData, response, error in
            if let error = error {
                print(error)
            }
            if let response = response as? HTTPURLResponse, response.statusCode == 204 {
                print("Inside Log out Response Closure")
                //print(HTTPCookieStorage.shared.cookies)
                // Clear cookie
                if let URLForCookie = response.url {
                    let allHeaderFields = response.allHeaderFields
                    let cookiesArray = HTTPCookie.cookies(withResponseHeaderFields: allHeaderFields as! [String : String], for:URLForCookie)
                    for cookie in cookiesArray {
                        HTTPCookieStorage.shared.deleteCookie(cookie)
                    }
                    
                }
                print("After clearing cookies")
                //print(HTTPCookieStorage.shared.cookies)
            }
            
            if let responseData = responseData {
                if let decodedResponseData = String(data: responseData, encoding: .utf8) {
                    
                    print("Response Data : \(decodedResponseData)")
                    
                }
            }
            
            userAuthenticationObject.checkAuthentication()
        }
        task.resume()
        print("After Logout Task Resume")
    }
    
    var body: some View {
        
                    
        NavigationStack {
            NavigationLink("Gallery"){
                if #available(iOS 15, *){
                    ImageViewiOS()
                }
                else{
                    ImageView()
                }
                
            }.accessibilityIdentifier("imageView")
//            NavigationLink("Authentication"){
//                //ImageView() // To Update
//            }
            
            Button("Log Out"){
                logoutAction()
                
            }
            
        }
        
    }
}

#Preview {
    MainPage()
}
