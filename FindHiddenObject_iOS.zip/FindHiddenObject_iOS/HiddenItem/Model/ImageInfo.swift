//
//  ImageInfo.swift
//  HiddenItem
//
//  Created by Yeon Tan on 13/01/2025.
//

import Foundation
import SwiftData

struct ImageInfo : Codable {
    let imageID: String
    let imageName: String
    let HiddenObjectPixelLocation: [String:[[String:Double]]]
    let imageURL: String
}

@Model
class TrackableImageHolder  {
    @Attribute(.unique) var imageID: String
    var imageName: String
    var HiddenObjectPixelLocation: [String:[[String:Double]]]
    var imageURL: String
    var isChallengeCompleted : Bool
    
    init ( imageID: String, imageName : String, HiddenObjectPixelLocation: [String:[[String:Double]]], imageURL : String, isChallengeCompleted: Bool = false){
        self.imageID = imageID
        self.imageName = imageName
        self.HiddenObjectPixelLocation = HiddenObjectPixelLocation
        self.imageURL = imageURL
        self.isChallengeCompleted = isChallengeCompleted
    }
}

enum testingError : Error {
    case testingE(String)
}

@Observable
class ImageHolder {
    
    var images: [ImageInfo] = []
 
    init (url: String) {

        Task {
            
            do {
                self.images = try await fetchData(url: url)
                
            }
//            catch testingError.testingE(let xx){
//                print(xx)
//            }
            catch {
                print(error)
            }
            
        }
    }
    
    func fetchData( url: String) async throws -> [ImageInfo] {
        
        let url = URL(string: url)
        
        let (data, response ) = try await URLSession.shared.data(from: url! , delegate: nil)
        
        guard let response = response as? HTTPURLResponse , (200...299).contains(response.statusCode) else {
            throw testingError.testingE("Testing Error")
        }
        print(data)
        return try JSONDecoder().decode([ImageInfo].self, from: data)
        
    }
    
    func extractLocation() {
        if images.isEmpty {
            return
        }
        for image in images {
            for (_, arrayOfLocation) in image.HiddenObjectPixelLocation {
                for coordinates in arrayOfLocation {
                    for (coordinate, value) in coordinates {
                        print("\(coordinate): \(value)")
                    }
                }
            }
        }
        
    }
    
    func showHiddenItems() -> [String] {
        if images.isEmpty {
            return []
        }
        
        var itemsList: [String] = []
        for image in images {
            for (items, arrayOfLocation) in image.HiddenObjectPixelLocation {
                itemsList.append(items)
            }
        }
        return itemsList
    }
    
    static let sharedImagesInfo = """
    [
      {
        "imageID": "8693eaf7-8e62-409e-8449-ac21698ca0f3",
        "imageName": "UnderTheSea",
        "HiddenObjectPixelLocation": {
          "cup": [
            {
              "x": 46,
              "y": 250
            },
            {
              "x": 68,
              "y": 252
            },
            {
              "x": 46,
              "y": 260
            },
            {
              "x": 71,
              "y": 265
            }
          ],
          "coin": [
            {
              "x": 206,
              "y": 520
            },
            {
              "x": 231,
              "y": 521
            },
            {
              "x": 205,
              "y": 529
            },
            {
              "x": 231,
              "y": 528
            }
          ],
          "fork": [
            {
              "x": 29,
              "y": 294
            },
            {
              "x": 54,
              "y": 295
            },
            {
              "x": 34,
              "y": 344
            },
            {
              "x": 50,
              "y": 346
            }
          ],
          "ring": [
            {
              "x": 472,
              "y": 535
            },
            {
              "x": 501,
              "y": 534
            },
            {
              "x": 474,
              "y": 546
            },
            {
              "x": 499,
              "y": 548
            }
          ],
          "sock": [
            {
              "x": 131,
              "y": 218
            },
            {
              "x": 142,
              "y": 218
            },
            {
              "x": 131,
              "y": 225
            },
            {
              "x": 142,
              "y": 224
            }
          ],
          "button": [
            {
              "x": 354,
              "y": 261
            },
            {
              "x": 374,
              "y": 263
            },
            {
              "x": 354,
              "y": 276
            },
            {
              "x": 371,
              "y": 278
            }
          ],
          "crayon": [
            {
              "x": 332,
              "y": 467
            },
            {
              "x": 346,
              "y": 470
            },
            {
              "x": 324,
              "y": 527
            },
            {
              "x": 338,
              "y": 528
            }
          ],
          "umbrella": [
            {
              "x": 257,
              "y": 134
            },
            {
              "x": 298,
              "y": 141
            },
            {
              "x": 260,
              "y": 143
            },
            {
              "x": 294,
              "y": 153
            }
          ],
          "horseshoe": [
            {
              "x": 311,
              "y": 309
            },
            {
              "x": 329,
              "y": 314
            },
            {
              "x": 309,
              "y": 332
            },
            {
              "x": 330,
              "y": 332
            }
          ],
          "toothbrush": [
            {
              "x": 228,
              "y": 234
            },
            {
              "x": 240,
              "y": 234
            },
            {
              "x": 226,
              "y": 265
            },
            {
              "x": 234,
              "y": 270
            }
          ]
        },
        "imageURL": "/UnderTheSea.jpg"
      },
      {
        "imageID": "6da1439e-9941-40c4-81fe-b2604ebae894",
        "imageName": "Room",
        "HiddenObjectPixelLocation": {
          "shoe": [
            {
              "x": 310,
              "y": 123
            },
            {
              "x": 334,
              "y": 133
            },
            {
              "x": 310,
              "y": 150
            },
            {
              "x": 335,
              "y": 150
            }
          ],
          "clock": [
            {
              "x": 370,
              "y": 190
            },
            {
              "x": 405,
              "y": 193
            },
            {
              "x": 372,
              "y": 211
            },
            {
              "x": 398,
              "y": 209
            }
          ],
          "bottle": [
            {
              "x": 66,
              "y": 91
            },
            {
              "x": 80,
              "y": 94
            },
            {
              "x": 65,
              "y": 137
            },
            {
              "x": 80,
              "y": 139
            }
          ],
          "shovel": [
            {
              "x": 46,
              "y": 197
            },
            {
              "x": 75,
              "y": 202
            },
            {
              "x": 31,
              "y": 247
            },
            {
              "x": 49,
              "y": 250
            }
          ],
          "lifebuoy": [
            {
              "x": 276,
              "y": 42
            },
            {
              "x": 335,
              "y": 49
            },
            {
              "x": 273,
              "y": 103
            },
            {
              "x": 321,
              "y": 103
            }
          ]
        },
        "imageURL": "/Room.jpg"
      },
      {
        "imageID": "7b298696-6b03-4d9a-ae6d-74b683f2b3b2",
        "imageName": "Beach",
        "HiddenObjectPixelLocation": {
          "fish": [
            {
              "x": 492,
              "y": 351
            },
            {
              "x": 514,
              "y": 353
            },
            {
              "x": 490,
              "y": 361
            },
            {
              "x": 513,
              "y": 365
            }
          ],
          "kite": [
            {
              "x": 265,
              "y": 391
            },
            {
              "x": 279,
              "y": 393
            },
            {
              "x": 263,
              "y": 411
            },
            {
              "x": 276,
              "y": 420
            }
          ],
          "sock": [
            {
              "x": 418,
              "y": 297
            },
            {
              "x": 459,
              "y": 301
            },
            {
              "x": 418,
              "y": 327
            },
            {
              "x": 445,
              "y": 329
            }
          ],
          "shell": [
            {
              "x": 475,
              "y": 762
            },
            {
              "x": 498,
              "y": 765
            },
            {
              "x": 477,
              "y": 782
            },
            {
              "x": 501,
              "y": 785
            }
          ],
          "mussel": [
            {
              "x": 65,
              "y": 658
            },
            {
              "x": 98,
              "y": 661
            },
            {
              "x": 66,
              "y": 688
            },
            {
              "x": 95,
              "y": 681
            }
          ],
          "starfish": [
            {
              "x": 156,
              "y": 758
            },
            {
              "x": 186,
              "y": 761
            },
            {
              "x": 154,
              "y": 788
            },
            {
              "x": 184,
              "y": 790
            }
          ]
        },
        "imageURL": "/Beach.jpg"
      },
      {
        "imageID": "wtf123",
        "imageName": "Garden",
        "HiddenObjectPixelLocation": {
          "ring": [
            {
              "x": 1,
              "y": 1
            }
          ]
        },
        "imageURL": "/Garden.jpg"
      },
      {
        "imageID": "greetings123",
        "imageName": "Greetings",
        "HiddenObjectPixelLocation": {
          "pencil": [
            {
              "x": 1,
              "y": 1
            }
          ]
        },
        "imageURL": "/Greetings.jpg"
      }
    ]
    """
    
}


