//
//  IsInPolygon.swift
//  HiddenItem
//
//  Created by Yeon Tan on 15/01/2025.
//

import Foundation

func isPointInPolygon(point: CGPoint, vertices: [CGPoint]) -> Bool {
    guard vertices.count > 2 else {
        return false // A polygon must have at least 3 vertices
    }

    var isInside = false
    let count = vertices.count

    var j = count - 1 // Index of the last vertex
    for i in 0..<count {
        let vertex1 = vertices[i]
        let vertex2 = vertices[j]
        
        // Check if the point is within the Y range of the edge
        if (vertex1.y > point.y) != (vertex2.y > point.y) {
            // Calculate the X coordinate of the intersection point of the edge with the horizontal line at point.y
            let intersectionX = vertex1.x + (point.y - vertex1.y) * (vertex2.x - vertex1.x) / (vertex2.y - vertex1.y)
            if point.x < intersectionX {
                isInside.toggle()
            }
        }
        j = i
    }
    return isInside
}
