//
//  LoginPage.swift
//  HiddenItem
//
//  Created by Yeon Tan on 17/01/2025.
//

import SwiftUI

struct signupDetail : Codable {
    var signup_username: String
    var signup_password: String
}

struct loginDetail : Codable {
    var login_username: String
    var login_password: String
}

struct responseErrors : Decodable {
    struct errorDetail : Decodable {
        let type : String
        let path : String
        let msg : String
        
    }
    let errors : [errorDetail]
}

struct AnimationObject  {
    var offsetX = 1.0
    var offsetY = 1.0
    var rotateDegree = Angle.zero
}

struct LoginPage: View {
    @State var loginUserName: String = ""
    @State var signupUserName: String = ""
    @State var loginPassword: String = ""
    @State var signupPassword: String = ""
    @State var showSignupModal: Bool = false
    @Environment(userAuthentication.self) var userAuthenticate
    let loginURL = "http://localhost:6688/login"
    let signupURL = "http://localhost:6688/signup"
    
    @State var loginSubmitInProgress: Bool = false
    @State var signupSubmitInProgress: Bool = false
    @State var isSignupSuccess: Bool = false
    @State var isLoginFailed: Bool = false
    @State var LoginFailureMessage: String = ""
    
    @State var isSignupFailed: Bool = false
    @State var signupErrorMessage:[String:String] = [:]
    
    @State var isShake: Bool = false
    @State var signupFailureTimes : Int = 0
    @State var isSignupFailedForAnimation : Bool = false
    
    func login(url: String, loginDetail : loginDetail) {
        // http://backend_mongo:6688/login
        
        let url = URL(string: url)
        var postRequest = URLRequest(url: url!)
        postRequest.httpMethod = "POST"
        postRequest.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        //let loginDetailData = try? JSONEncoder().encode(loginDetail)
        
        let loginDetailWithAddingPercentEncoding = ["login_username": loginDetail.login_username, "login_password": loginDetail.login_password].map { "\($0.key)=\($0.value)"}.joined(separator: "&").addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let encodedLoginDetailData = loginDetailWithAddingPercentEncoding.data(using: .utf8)
        
        let task = URLSession.shared.uploadTask(with: postRequest , from: encodedLoginDetailData) { ResponseData, response, error in
            
            if let error = error {
                print ("Error is \(error)")
                return
            }
            
            if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                print("Getting Status Code 200 from BackEnd in Login Page")
                if let urlForCookie = response.url, let httpHeaderFields = response.allHeaderFields as? [String: String] {
                    //print(httpHeaderFields)
                    let loginCookiesArray = HTTPCookie.cookies(withResponseHeaderFields: httpHeaderFields, for: urlForCookie)
                    HTTPCookieStorage.shared.setCookies(loginCookiesArray, for: urlForCookie, mainDocumentURL: nil)
                    //print(HTTPCookieStorage.shared.cookies)
                    print("Finish setting Cookies for login")
                    
                }
                
                
            }
            if let data = ResponseData {
                
                if let decodedData = String(data: data, encoding: .utf8){
                    print ("Response Data is \(decodedData)")
                    if decodedData == "OK" {
                        loginSubmitInProgress = false
                        userAuthenticate.isAuthenticated = true
                    }
                    else {
                        print("Incorrect Response")
                        isLoginFailed = true
                        LoginFailureMessage = decodedData
                        isShake = true
                        
                    }
                    
                }
            }
                
                
            
        }
        task.resume()
        
    }
    
    func signup( url: String, detail: signupDetail){
        
        //http://backend_mongo:6688/signup
        
        let url = URL(string: url)
        var request = URLRequest(url: url!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let detailData = ["signup_username" : detail.signup_username, "signup_password" : detail.signup_password]
        let detailData_addingPercentEncoding = detailData.map{ "\($0.key)=\($0.value)"}.joined(separator: "&").addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        
    let encodedData = detailData_addingPercentEncoding.data(using: .utf8)
        //guard let signupDetailData = try? JSONEncoder().encode(detail) else { return }
        
        print("Inside Sign Up Function in Login Page")
        let task = URLSession.shared.uploadTask(with: request , from: encodedData) { data, response, error in
            print("Inside Sign Up Task")
            print("details are \(detail)")
            if let error = error {
                print ("Error is \(error)")
                return
            }
            if let response = response as? HTTPURLResponse, response.statusCode == 201  {
                
                print("Sign Up successfully from Back End")
                //                if let fields = response.allHeaderFields as? [String: String],
                //                   let urlForCookie = response.url {
                //                    let cookies = HTTPCookie.cookies(withResponseHeaderFields: fields, for: urlForCookie)
                //                    HTTPCookieStorage.shared.setCookies(cookies, for: urlForCookie, mainDocumentURL: nil)
                //                }
                
                signupSubmitInProgress = false
                showSignupModal = false
                isSignupSuccess = true
                
            }
            else if let responseData = data {
                print(response ?? "No Response")
                let convertedData = String(data: responseData, encoding: .utf8) ?? "No Data"
                print(convertedData)
                
                let decodedErrors = try! JSONDecoder().decode(responseErrors.self, from: responseData)
                print("Type of decodedErros is \(type(of:decodedErrors))")
                let errors = decodedErrors.errors
                for error in errors {
                    if error.path == "signup_username" {
                        signupErrorMessage["username"] = error.msg
                    }
                    else if error.path == "signup_password" {
                        signupErrorMessage["password"] = error.msg
                    }
                }
                
                if !signupErrorMessage.isEmpty {
                    
                    isSignupFailed = true
                    print("isSignupFailed is true")
                }
            }
                
        }
    
        task.resume()
    }
    
    var body: some View {
        
        
        VStack {
             
            HStack {
                Spacer()
                if loginSubmitInProgress {
                    ProgressView().font(.caption)
                }
                Spacer()
            }.padding(10)
            Form {
                Section(header: Text("Log In")) {
                    HStack {
                        Text("Username").accessibilityIdentifier( "loginUserNameLabel")
                        TextField("Input Username", text: $loginUserName).textInputAutocapitalization(.never)
                            .accessibilityIdentifier("loginUserName")
                    }
                    HStack {
                        Text("Password")
                        SecureField("Password", text: $loginPassword).textInputAutocapitalization(.never)
                            .onSubmit{
                            // Submit to Back End to Log In
                            
                            login(url: loginURL, loginDetail: loginDetail(login_username: loginUserName, login_password: loginPassword))
                            
                        }
                            .accessibilityIdentifier("loginPassword")
                    }
                }
            
                
            }.scrollContentBackground(.hidden).frame(width: 300, height: 150)
                .border(Color.gray)
                .keyframeAnimator(
                    initialValue: AnimationObject(),
                    trigger: isShake
                ) { content, value in
                    
                    content.offset(x: value.offsetX )
                    .offset(y: value.offsetY )
                    .rotationEffect(value.rotateDegree)
                    
                } keyframes: { AnimationObject in
                    KeyframeTrack(\.offsetX) {
                        //SpringKeyframe(1, duration: 0.1 , spring: .bouncy)
                        SpringKeyframe(-1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-3, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(3, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-3, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(3, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(1, duration: 0.04167, spring: .bouncy)
                        SpringKeyframe(1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(0, duration: 0.04167 , spring: .bouncy)
                    }
                    KeyframeTrack(\.offsetY) {
                        //SpringKeyframe(1, duration: 0.1 , spring: .bouncy)
                        SpringKeyframe(-2, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(0, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(2, duration: 0.04167, spring: .bouncy)
                        SpringKeyframe(-1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(2, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-1, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(2, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(-2, duration: 0.04167 , spring: .bouncy)
                        SpringKeyframe(0, duration: 0.04167 , spring: .bouncy)
                    }
                    KeyframeTrack(\.rotateDegree) {
                        CubicKeyframe(.degrees(-5), duration: 0.04167)
                        CubicKeyframe(.degrees(5), duration: 0.04167)
                        CubicKeyframe(.degrees(0), duration: 0.04167)
                        CubicKeyframe(.degrees(5), duration: 0.04167)
                        CubicKeyframe(.degrees(-5), duration: 0.04167)
                        CubicKeyframe(.degrees(0), duration: 0.04167)
                        CubicKeyframe(.degrees(-5), duration: 0.04167)
                        CubicKeyframe(.degrees(5), duration: 0.04167)
                        CubicKeyframe(.degrees(0), duration: 0.04167)
                        CubicKeyframe(.degrees(-5), duration: 0.04167)
                        CubicKeyframe(.degrees(0), duration: 0.04167)
                    }
                }
            
            
            HStack{
                
                Spacer()
                Button("Log In") {
                    // Submit to Back End to Log In
                    loginSubmitInProgress = true
                    login(url: loginURL, loginDetail: loginDetail(login_username: loginUserName, login_password: loginPassword))
                }
                .disabled((loginUserName=="" || loginPassword==""))
                .accessibilityIdentifier("loginButton")
                Spacer()
            }.padding(5)
        
            HStack{
                Text("To register a new account").accessibilityIdentifier("signupDescription")
                Button("Sign Up") {
                    // Show Sign Up Modal
                    showSignupModal = true
                }
                .accessibilityIdentifier("signupButton")
            }
            
            
        }
         //Sign Up Modal
        .sheet(isPresented: $showSignupModal) {
            VStack {
                HStack{
                    Spacer()
                    if signupSubmitInProgress {
                        ProgressView()
                    }
                    Spacer()
                }
                Form {
                    Section(header: Text("Sign Up")) {
                        HStack {
                            Text("Username")
                            TextField("Required", text: $signupUserName).textInputAutocapitalization(.never)
                                .accessibilityIdentifier("signupUserName")
                        }
                        HStack {
                            Text("Password")
                            SecureField("Required", text: $signupPassword).textInputAutocapitalization(.never)
                                .accessibilityIdentifier("signupPassword")
//                                .onSubmit{
//                                // Submit to Back End to create new account
//                                signup(url: signupURL, detail: signupDetail(signup_username: signupUserName, signup_password: signupPassword))
//                                showSignupModal = false
//                            }
                        }
                    }
                     
                }.scrollContentBackground(.hidden).frame(width: 300, height: 150)
                    .border(Color.gray)
                    .keyframeAnimator(
                        initialValue: AnimationObject(),
                        trigger: signupFailureTimes
                    ) { content, value in
                        
                        content.offset(x: value.offsetX )
                        .offset(y: value.offsetY )
                        .rotationEffect(value.rotateDegree)
                        
                    } keyframes: { AnimationObject in
                        KeyframeTrack(\.offsetX) {
                            //SpringKeyframe(1, duration: 0.1 , spring: .bouncy)
                            SpringKeyframe(-1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-3, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(3, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-3, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(3, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(1, duration: 0.05, spring: .bouncy)
                            SpringKeyframe(1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(0, duration: 0.05 , spring: .bouncy)
                        }
                        KeyframeTrack(\.offsetY) {
                            //SpringKeyframe(1, duration: 0.1 , spring: .bouncy)
                            SpringKeyframe(-2, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(0, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(2, duration: 0.05, spring: .bouncy)
                            SpringKeyframe(-1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(2, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-1, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(2, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(-2, duration: 0.05 , spring: .bouncy)
                            SpringKeyframe(0, duration: 0.05 , spring: .bouncy)
                        }
                        KeyframeTrack(\.rotateDegree) {
                            CubicKeyframe(.degrees(-5), duration: 0.05)
                            CubicKeyframe(.degrees(5), duration: 0.05)
                            CubicKeyframe(.degrees(0), duration: 0.05)
                            CubicKeyframe(.degrees(5), duration: 0.05)
                            CubicKeyframe(.degrees(-5), duration: 0.05)
                            CubicKeyframe(.degrees(0), duration: 0.05)
                            CubicKeyframe(.degrees(-5), duration: 0.05)
                            CubicKeyframe(.degrees(5), duration: 0.05)
                            CubicKeyframe(.degrees(0), duration: 0.05)
                            CubicKeyframe(.degrees(-5), duration: 0.05)
                            CubicKeyframe(.degrees(0), duration: 0.05)
                        }
                    }
                    .onAppear() {
                        if isSignupFailedForAnimation {
                            isSignupFailedForAnimation = false
                            signupFailureTimes = signupFailureTimes + 1
                        }
                    }
                
                HStack{
                    
                    Spacer()
                    Button("Sign Up") {
                        // Submit to Back End to create new account
                        print("Inside Sign Up Button Action")
                        signupSubmitInProgress = true
                        signup(url: signupURL, detail: signupDetail(signup_username: signupUserName, signup_password: signupPassword))
                        print("End of Button Action")
                        
                    }
                    .disabled((signupUserName=="" || signupPassword==""))
                    .accessibilityIdentifier("signupSubmitButton")
                    
//                    .rotationEffect(.degrees(isSignupFailed ? 0 : 0 ))
//                    .animation(.spring, value: isSignupFailed)
//                    .rotationEffect(.degrees(isSignupFailed ? -55 : 0 ))
//                    .animation(.spring, value: isSignupFailed)
                    
                    Spacer()
                }.padding(5)
                Button("Go back"){
                    showSignupModal = false
                }
            }
        }
        //.accessibilityIdentifier("signupModal")
        
        .alert("Sign Up Successfully", isPresented: $isSignupSuccess) {
            Button("Ok"){
                signupUserName = ""
                signupPassword = ""
                
            }
            .accessibilityIdentifier("signupSuccessfullyAlertButton")
        }
        
        // Alert for Log In
        .alert ("Failed to Log In", isPresented: $isLoginFailed, presenting: LoginFailureMessage) { _ in
            Button("Try Again"){
                loginUserName = ""
                loginPassword = ""
                loginSubmitInProgress = false
                isShake = false
            }
        } message: { loginFailureMessage in
            Text(loginFailureMessage)
        }
        
        // Alert for Signup
        .alert ("Failed to Signup", isPresented: $isSignupFailed, presenting: signupErrorMessage) { _ in
            Button("Try Again"){
                signupUserName = ""
                signupPassword = ""
                signupSubmitInProgress = false
                showSignupModal = true
                signupErrorMessage = [:]
                isSignupFailedForAnimation = true
            }
        } message: { signupErrorMessage in
            VStack {
                
                if (signupErrorMessage.keys.contains("username")) {
                    Text(signupErrorMessage["username"] ?? "")
                }
                if (signupErrorMessage.keys.contains("password")) {
                    Text(signupErrorMessage["password"] ?? "")
                }
            }
        }
        //
    }
    
}

#Preview {
    LoginPage()
}
