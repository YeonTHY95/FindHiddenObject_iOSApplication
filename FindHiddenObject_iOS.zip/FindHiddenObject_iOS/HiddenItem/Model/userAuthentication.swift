//
//  userAuthentication.swift
//  HiddenItem
//
//  Created by Yeon Tan on 17/01/2025.
//

import Foundation

@Observable
class userAuthentication {
    var isAuthenticated: Bool = false
    let refreshTokenURL = "http://localhost:6688/refreshToken"
    func checkAuthentication() {
        print("Inside checkAuthentication")
        if let cookiesArray = HTTPCookieStorage.shared.cookies {
            let accessToken = cookiesArray.filter{ $0.name == "accessCookie"}
            if !accessToken.isEmpty && accessToken.first?.value.isEmpty == false {
                print("accessToken is not empty")
                self.isAuthenticated = true
            }
            else {
                let refreshToken = cookiesArray.filter{ $0.name == "refreshCookie"}
                if !refreshToken.isEmpty && refreshToken.first?.value.isEmpty == false {
                    // Make request to renew accessToken
                    let refreshTokenRequest = URLRequest(url : URL(string:refreshTokenURL)!)
                    let refreshTokenTask = URLSession.shared.dataTask(with: refreshTokenRequest) { (data, response, error) in
                        print("Inside refreshTokenTask")
                         if let error = error {
                            print(error)
                        }
                        if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                            print("Inside Refresh Token Task Success")
                            if let refreshTokenResponseURL = response.url{
                                let allHeadersFields = response.allHeaderFields as! [String: String]
                                let refreshTokenCookiesArray = HTTPCookie.cookies(withResponseHeaderFields: allHeadersFields, for: refreshTokenResponseURL)
                                HTTPCookieStorage.shared.setCookies(refreshTokenCookiesArray, for: refreshTokenResponseURL, mainDocumentURL: nil)
                            }
                            self.isAuthenticated = true
                        }
                        else {
                            print("Refresh Token Task Status Code is not 200")
                            self.isAuthenticated = false
                        }
                        
                        if let responseData = data {
                            let encodedResponseData = String(data: responseData, encoding: .utf8)
                            print("Refresh Encoded Response Data is \(encodedResponseData)")
                        }
                        
                    }
                    
                }
                else {
                    print("Even RefreshToken is empty")
                    self.isAuthenticated = false
                }
            }
        }
        
    }
}
