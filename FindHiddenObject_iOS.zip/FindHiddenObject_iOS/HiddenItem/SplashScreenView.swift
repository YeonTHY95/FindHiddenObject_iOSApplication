//
//  SplashScreenView.swift
//  HiddenItem
//
//  Created by Yeon Tan on 26/02/2025.
//

import SwiftUI
import Lottie

struct SplashScreenView: View {
    @Binding var isSplashScreenShown: Bool
    var body: some View {
        ZStack {
            LottieView(animation: .named("FindHiddenObjectSplashScreen_1000x1000.json"))
                .configure ({ lottieAnimationView in
                    lottieAnimationView.frame = CGRect(x: 0, y: 0, width: 1000, height: 1000)
                    lottieAnimationView.contentMode = .scaleAspectFill
                    
                })
                .playbackMode(.playing(.toProgress(1, loopMode: .playOnce)))
                .animationDidFinish { completed in
                    if completed {
                        isSplashScreenShown = true
                    }
                }
        }
        
    }
}

//#Preview {
//    SplashScreenView()
//}
