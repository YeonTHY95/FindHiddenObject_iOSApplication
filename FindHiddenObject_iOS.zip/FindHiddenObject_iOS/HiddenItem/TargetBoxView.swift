//
//  TargetBoxView.swift
//  HiddenItem
//
//  Created by Yeon Tan on 16/01/2025.
//

import SwiftUI


struct TargetBoxView: View {
    @Binding var targetBoxCoordinates : CGPoint?
    @State var isAfterDelay : Bool = false
    
    
    var body: some View {
        if let tbc = targetBoxCoordinates {
            
            Image("cross").resizable().frame(width: 30,height: 30).position(tbc).opacity( isAfterDelay ? 0 : 1).onChange(of: tbc, initial: true){
                Task{
                    do {
                        isAfterDelay = false
                        try await Task.sleep(for: .seconds(0.3))
                        isAfterDelay = true
                    }
                    catch {
                        print (error)
                    }
                }
                
                //let _ = print("Target Box Coordinates: \(tbc)")
            }
            
            
            
            
        }
        else {
            Image("tick").resizable().frame(width: 30,height: 30).opacity(0)
        }
        
        
    }
}

//#Preview {
//    TargetBoxView()
//}
