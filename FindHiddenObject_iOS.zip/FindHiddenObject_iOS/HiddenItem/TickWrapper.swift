//
//  TickWrapper.swift
//  HiddenItem
//
//  Created by Yeon Tan on 17/01/2025.
//

import SwiftUI
import AVFoundation

struct TickWrapper: View {
    var targetBoxCoordinate : CGPoint
    var correctLocatedItems : [String]
    @State var itemsWithCoordinates : [String : CGPoint] = [:]
    var locatedCorrectly : Bool
    @State var correctSoundEffect : AVAudioPlayer?
    
//    {
//        let soundULR = Bundle.main.url(forResource: "correctSoundEffect", withExtension: "mp3")
//        
//        return try? AVAudioPlayer(contentsOf: soundULR!)
//        
//    }
    var body: some View {
        ForEach(correctLocatedItems, id:\.self){ item in
            if let coordinate = itemsWithCoordinates[item] {
                Image("tick").resizable().frame(width: 30,height: 30).position(coordinate).onAppear{
                    
                    do {
                        let soundULR = Bundle.main.url(forResource: "correctSoundEffect", withExtension: "mp3")
                        correctSoundEffect = try AVAudioPlayer(contentsOf: soundULR!)
                    }
                    catch {
                        print(error)
                    }
                    
                    //correctSoundEffect.seek(to:.zero)
                    if let correctSoundEffect = correctSoundEffect {
                        correctSoundEffect.volume = 1.0
                        correctSoundEffect.play()
                        //print("Play Sound Effect")
                    }
                    else {
                        print("No Sound")
                        return
                    }
                    
                    
                }
                
            }
        }
        
        .onChange(of: correctLocatedItems, initial: true) { old, new in
//            print("Old item is \(old)")
//            print("New item is \(new)")
            if !new.isEmpty {
                let toBeAdded = new.filter { !old.contains($0)}
                //print("New item is added: \(toBeAdded)")
                
                if let lastItem = toBeAdded.first {
                    if locatedCorrectly {
                        itemsWithCoordinates[lastItem] = targetBoxCoordinate
                    }
                    
                }
            }
            
            
        }
    }
}

//#Preview {
//    TickWrapper()
//}
