
//
//  HiddenItemUITests.swift
//  HiddenItemUITests
//
//  Created by Yeon Tan on 09/01/2025.
//

import XCTest

final class HiddenItemUITests: XCTestCase {

    //var app :XCUIApplication!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        //app = XCUIApplication()
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        //app.launch()
        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    @MainActor
    func testExample() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        
        let loginUserNameLabel = app.staticTexts["loginUserNameLabel"]
        XCTAssertTrue(loginUserNameLabel.exists, "Does not detect login UserName Label")
        
        let signupDescription = app.staticTexts["signupDescription"]
        XCTAssertTrue(signupDescription.exists, "Does not detect signup description")
        
        // Click Sign Up Button to register a new account
        let signupButton = app.buttons["signupButton"]
        XCTAssert(signupButton.exists, "Does not detect signup button")
        
        signupButton.tap()
        
//        let signupModal = app.sheets["signupModal"]
//        XCTAssert(signupModal.exists, "Does not detect signup Modal")
        
        let usernameTextField = app.textFields["signupUserName"]
        let passwordTextField = app.secureTextFields["signupPassword"]
        let signupSubmitButton = app.buttons["signupSubmitButton"]
        
        XCTAssert(signupSubmitButton.exists, "Does not detect signup Submit Button")
        XCTAssert(usernameTextField.exists, "Does not detect username text field")
        XCTAssert(passwordTextField.exists, "Does not detect password text field")
        
        // Key in Information for registration
        usernameTextField.tap()
        
        let randomNumber = Int.random(in: 1..<1000);
        let randomUserName = "testxuser\(randomNumber)"
        usernameTextField.typeText(randomUserName)
        
        //let passwordTextField = app.secureTextFields["signupPassword"]
        let randomPassword = "wwwtest"
        passwordTextField.tap()
        passwordTextField.typeText(randomPassword)
        
        signupSubmitButton.tap()
        
        let signupSuccessfullyAlertButton = app.buttons["signupSuccessfullyAlertButton"]
        XCTAssertTrue(signupSuccessfullyAlertButton.waitForExistence(timeout: 5),"Does not detect signUp Modal Ok Button")
        // Click Ok Button of Successful SignUp Modal
        signupSuccessfullyAlertButton.tap()
        
        // Login Button
        let loginButton = app.buttons["loginButton"]
        XCTAssert(loginButton.exists, "Does not detect login button")
        
        let loginUserNameTextField = app.textFields["loginUserName"]
        let loginPasswordTextField = app.secureTextFields["loginPassword"]
        
        XCTAssert(loginUserNameTextField.exists, "Does not detect login username text field")
        XCTAssert(loginPasswordTextField.exists, "Does not detect login password text field")
        
        //Login
        loginUserNameTextField.tap()
        loginUserNameTextField.typeText(randomUserName)
        loginPasswordTextField.tap()
        loginPasswordTextField.typeText(randomPassword)
        
        loginButton.tap()
        
        //After login
        let imageView = app.buttons["imageView"]
        XCTAssertTrue(imageView.waitForExistence(timeout: 5), "After login, the imageView should be presented.")
        XCTAssert(imageView.isHittable, "ImageView should be hittable")
        
        imageView.tap()
        
        let RoomImageView = app.buttons["Room"]
        RoomImageView.tap()
        
        let FindHiddenItemsChallenge=app.images["FindHiddenItemsChallenge"]
        XCTAssert(FindHiddenItemsChallenge.waitForExistence(timeout: 5), "FindHiddenItemsChallenge should be presented.")
        
        FindHiddenItemsChallenge.tap()
        
        let location = FindHiddenItemsChallenge.coordinate(withNormalizedOffset: CGVector(dx: 0.0, dy: 0.0))
        
        let tapLocation = location.withOffset(CGVector(dx: 50, dy: 100))
        tapLocation.tap()
        
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    @MainActor
    func testLaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 7.0, *) {
            // This measures how long it takes to launch your application.
            measure(metrics: [XCTApplicationLaunchMetric()]) {
                XCUIApplication().launch()
            }
        }
    }
}
